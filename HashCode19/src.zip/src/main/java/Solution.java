import domain.Photo;
import domain.Slideshow;

import java.util.List;

public interface Solution {
    Slideshow solve(List<Photo> photos);
}
