public enum PhotoType {

    VERTICAL,
    HORIZONTAL
}
